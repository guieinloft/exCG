typedef struct keys_t {
	bool k_up;
	bool k_down;
	bool k_left;
	bool k_right;
	bool k_pgup;
	bool k_pgdown;
	bool shift;
	bool ctrl;
} Keys;
