#ifndef CIRCLE_H
#define CIRCLE_H

#include "Vector2.h"

//classe para usar nas colisoes
class Circle {
public:
	Vector2 c;
	float r;
};

#endif
